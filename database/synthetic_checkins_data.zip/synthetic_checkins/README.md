# Synthetic check-in data (testing only)

Fake daily and weekly check-in answers attached to `fitness_tracker_dataset.csv`. No real patient data. Rebuild or change it with `generate_synthetic_checkins.py` (fixed seed, so it reproduces exactly).

## How it links to the fitness data
Join on `user_id` + `date`. Check-ins exist only on days the user has fitness rows (the fitness file has ~1.6 rows per user-day), so every response has at least one matching fitness row. Weekly check-ins use the Sunday ending the week.

## Tables
| File | Grain | Key columns |
|---|---|---|
| `question_bank.csv` | one row per question | `question_id`, `domain`, `period` (morning/evening/weekly), `role` (primary/followup/conditional/provider), `response_type`, `options` |
| `users.csv` | one row per user_id | `domains` (pipe-separated), `goal_domain`, `base_tier`, `provider_questions`, `sim_*` traits (drop these in the app, they only drive the simulation) |
| `checkins.csv` | one row per check-in opportunity | `status` = completed / partial (first question only) / skipped, `tier_offered`, `n_answered`, `submitted_at` |
| `responses.csv` | one row per answered question | `checkin_id`, `user_id`, `date`, `question_id`, `response_value` (text), `response_numeric` (scales, yes/no = 1/0, minutes, counts) |
| `tier_events.csv` | one row per adaptive change | `auto_downgrade` (reason: `missed_check_ins` or `only_first_question_answered`), `upgrade_offer_accepted`, `upgrade_offer_declined` |

`sample_50_users/` is the same set of tables cut to 50 users, plus their fitness rows, for quick testing. The full `checkins` and `responses` files are also provided as `.gz`.

## What is simulated (percentages are knobs at the top of the script)
- **Domains:** each user gets 1 (45%), 2 (35%) or 3 (20%) of the six domains. 15% of users get substance use. The first domain is their goal domain.
- **Base tier:** quick 30% / standard 45% / extended 25%.
- **Adaptive tiers:** 5 days in a row with no check-in, or 5 check-ins in a row answering only the first question, drops a user to quick. After 6 of 7 days engaged, they are offered their original tier again (60% accept, 14-day cooldown).
- **Nightly question (`GE0`):** "How content did you feel today?" on a 1-10 scale, asked first at every evening check-in that happened, outside the quick/standard/extended logic. Added afterwards by `add_nightly_content_question.py` without changing any other answer. Answers follow that day's fitness mood and sleep, whether the goal was met, and the user's motivation trait.
- **Conditional questions:** confidence 4 or lower triggers "adjust today's goal?". Goal not met triggers the encouraging "what would I tell a friend" question. Putting off bed triggers "what's keeping me awake". Goal not met in the substance domain triggers the trigger and coping questions.
- **Provider-added questions:** examples only (`PV1` to `PV4`). 40% of substance-use users get a daily craving rating, and other examples are spread across sleep, activity and general users.
- **Realism:** goal-met rate, confidence, calm, loneliness and similar answers shift with that day's `mood`, `sleep_hours`, `steps` and `workout_type`, plus a per-user motivation trait and a per-user adherence trait (including lapses and slow drop-off).

## Known limitations
- The fitness file is itself random (for example `active_minutes` above 1,440 and workouts that don't match steps), so answers only loosely track it.
- Free-text answers come from small phrase pools, so they repeat a lot.
- Quick-tier users get no domain-specific daily questions (only the general primary questions), per the "one primary question" design.
