# Run with Docker

One command starts the backend, the database and the pages. Needs Docker Desktop running.

```
docker compose up -d --build
```

Open http://127.0.0.1:5173/login.html. The API docs are at http://127.0.0.1:8000/docs.

## Pick how many patients

Set `PATIENTS` (50 up to 999). 50 uses the ready-made `V2/database/sample.db`. Anything else is built from `V2/database/synthetic_v2_data.zip` (the first N patients), which takes longer on the first start.

```
PATIENTS=100 docker compose up -d --build            # Mac / Linux
$env:PATIENTS=100; docker compose up -d --build      # Windows PowerShell
```

Changing `PATIENTS` rebuilds the database on the next start.

## Reset

The database lives in a Docker volume, so it survives restarts. To wipe it and start clean:

```
./reset.sh 100        # Mac / Linux
.\reset.ps1 -Patients 100   # Windows PowerShell
```

Leave the number off for 50 patients.

## Look at or copy the database

```
docker compose cp backend:/data/app.db ./app.db
```

Stop everything with `docker compose down` (keeps the data) or `docker compose down -v` (deletes it).
