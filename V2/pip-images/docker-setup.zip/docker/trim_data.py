"""Keep only the first N patients of the synthetic data folder.

  python trim_data.py <source folder> <destination folder> <N>

Reads and writes the CSV files that build_v2_db.py loads. Streams row by row, so the big answers file never sits in memory.
"""
import csv
import sys
from pathlib import Path

csv.field_size_limit(sys.maxsize)


def filtered(src: Path, dst: Path, keep_row) -> None:
    with open(src, newline="", encoding="utf-8") as fin, open(dst, "w", newline="", encoding="utf-8") as fout:
        reader, writer = csv.reader(fin), csv.writer(fout, lineterminator="\n")
        header = next(reader)
        writer.writerow(header)
        keep = keep_row(header)
        writer.writerows(row for row in reader if keep(row))


def main(src_dir: str, dst_dir: str, n: int) -> None:
    src, dst = Path(src_dir), Path(dst_dir)
    dst.mkdir(parents=True, exist_ok=True)

    def by_patient(header):
        i = header.index("patient_id")
        return lambda row: int(row[i]) <= n

    for name in ("patients.csv", "patient_domains.csv", "patient_questions.csv"):
        filtered(src / name, dst / name, by_patient)

    kept_checkins = set()

    def checkins_filter(header):
        p, c = header.index("patient_id"), header.index("checkin_id")

        def keep(row):
            if int(row[p]) <= n:
                kept_checkins.add(row[c])
                return True
            return False
        return keep

    filtered(src / "checkins.csv", dst / "checkins.csv", checkins_filter)

    def answers_filter(header):
        c = header.index("checkin_id")
        return lambda row: row[c] in kept_checkins

    filtered(src / "answers.csv", dst / "answers.csv", answers_filter)
    print(f"Trimmed to the first {n} patients: {len(kept_checkins)} check-ins kept.", flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]))
