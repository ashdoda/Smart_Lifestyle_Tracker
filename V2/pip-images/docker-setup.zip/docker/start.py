"""Container start-up: build the app database on first start (or when PATIENTS changes), then run the API.

PATIENTS  how many patients the app database holds: 50 uses the ready-made sample database,
          51-999 builds a database from the synthetic data zip (first N patients).
TRACKER_DB  where the app database lives (a Docker volume, so it survives restarts).
RESET=1   throw the database away and rebuild it.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

APP_DIR = Path(os.environ.get("APP_DIR", "/app"))
BACKEND_DIR = APP_DIR / "backend"
DATABASE_DIR = APP_DIR / "database"
DB = Path(os.environ.get("TRACKER_DB", "/data/app.db"))
MARKER = DB.parent / "patients.txt"
SAMPLE_SIZE = 50
MAX_PATIENTS = 999


def run(*args, cwd=None):
    subprocess.run([str(a) for a in args], check=True, cwd=cwd)


def wanted_patients() -> int:
    n = int(os.environ.get("PATIENTS", SAMPLE_SIZE))
    if not 1 <= n <= MAX_PATIENTS:
        sys.exit(f"PATIENTS must be between 1 and {MAX_PATIENTS} (got {n}).")
    return n


def needs_build(n: int) -> bool:
    if os.environ.get("RESET") == "1" or not DB.exists() or not MARKER.exists():
        return True
    return MARKER.read_text().strip() != str(n)


def build_source(n: int, work: Path) -> Path:
    """The database file the app database is copied from."""
    if n == SAMPLE_SIZE:
        return DATABASE_DIR / "sample.db"
    data = work / "data"
    print(f"Unpacking the synthetic data ({n} patients wanted)...", flush=True)
    with zipfile.ZipFile(DATABASE_DIR / "synthetic_v2_data.zip") as z:
        z.extractall(work / "raw")
    raw = work / "raw" / "synthetic_v2"
    run(sys.executable, APP_DIR / "trim_data.py", raw, data, n)
    out = work / "built.db"
    print("Building the database...", flush=True)
    run(sys.executable, DATABASE_DIR / "build_v2_db.py", "--data", data, "--out", out)
    return out


def prepare() -> None:
    n = wanted_patients()
    DB.parent.mkdir(parents=True, exist_ok=True)
    if not needs_build(n):
        print(f"Using the existing database ({MARKER.read_text().strip()} patients).", flush=True)
        return
    work = Path(tempfile.mkdtemp(prefix="tracker-build-"))
    try:
        source = build_source(n, work)
        run(sys.executable, "seed_demo.py", "--source", source, "--db", DB, "--reset", cwd=BACKEND_DIR)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    MARKER.write_text(str(n))
    print(f"Database ready: {n} patients.", flush=True)


def serve() -> None:
    os.chdir(BACKEND_DIR)
    os.execvp(sys.executable, [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"])


if __name__ == "__main__":
    prepare()
    serve()
