#!/bin/sh
# Wipe the app database and start fresh.   Usage: ./reset.sh [patients]    (default 50, up to 999)
cd "$(dirname "$0")" || exit 1
export PATIENTS="${1:-50}"
docker compose down -v
docker compose up -d --build
echo "Started with $PATIENTS patients. Open http://127.0.0.1:5173/login.html (first start with more than 50 patients takes a little while)."
