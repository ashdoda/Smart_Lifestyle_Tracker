# Wipe the app database and start fresh.   Usage: .\reset.ps1 [patients]    (default 50, up to 999)
param([int]$Patients = 50)
Set-Location $PSScriptRoot
$env:PATIENTS = $Patients
docker compose down -v
docker compose up -d --build
Write-Host "Started with $Patients patients. Open http://127.0.0.1:5173/login.html (first start with more than 50 patients takes a little while)."
